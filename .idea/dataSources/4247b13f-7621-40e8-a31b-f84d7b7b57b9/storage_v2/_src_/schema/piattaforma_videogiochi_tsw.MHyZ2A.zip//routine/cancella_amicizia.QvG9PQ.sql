create
    definer = root@localhost procedure cancella_amicizia(IN a_possessore varchar(20), IN a_amico varchar(20))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		DELETE FROM e_nella_friendlist WHERE Possessore = a_possessore AND Amico = a_amico;
        DELETE FROM e_nella_friendlist WHERE Possessore = a_amico AND Amico = a_possessore;
	COMMIT;
END;

