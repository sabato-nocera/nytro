create
    definer = root@localhost procedure rimuovi_recensione(IN a_codice int, IN a_username varchar(20))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SET @numero = (SELECT COUNT(*) FROM recensione WHERE recensione.videogioco = a_codice);
        SET @voto = (SELECT Voto FROM recensione WHERE recensione.videogioco = a_codice AND recensione.username = a_username);
		DELETE FROM recensione WHERE recensione.videogioco = a_codice AND recensione.username = a_username;
        IF (@numero > 1)
		THEN UPDATE videogioco SET voto_medio = (voto_medio*@numero - @voto)/(@numero-1) WHERE videogioco.codice = a_codice;
        ELSE UPDATE videogioco SET voto_medio = 0 WHERE videogioco.codice = a_codice;
        END IF;
	COMMIT;
END;

