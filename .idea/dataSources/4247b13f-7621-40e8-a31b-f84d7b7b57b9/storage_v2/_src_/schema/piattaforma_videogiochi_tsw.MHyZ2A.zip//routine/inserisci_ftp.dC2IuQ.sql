create
    definer = root@localhost procedure inserisci_ftp(IN a_ISIN char(12), IN a_data_rilascio date,
                                                     IN a_titolo varchar(50), IN a_PEGI int, IN a_image mediumblob,
                                                     IN a_genere varchar(15), IN a_modalita enum ('online', 'offline'))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO videogioco (ISIN, Data_Rilascio, Titolo, PEGI, Img)
		VALUES (a_ISIN, a_data_rilascio, a_titolo, a_PEGI, a_image);
        SET @numero = (SELECT Codice FROM Videogioco WHERE ISIN = a_ISIN AND data_rilascio = a_data_rilascio AND titolo = a_titolo AND PEGI = a_PEGI);
		INSERT INTO free_to_play VALUES (@numero, a_modalita);
        INSERT INTO genere VALUES (a_genere, @numero);
	COMMIT;
END;

