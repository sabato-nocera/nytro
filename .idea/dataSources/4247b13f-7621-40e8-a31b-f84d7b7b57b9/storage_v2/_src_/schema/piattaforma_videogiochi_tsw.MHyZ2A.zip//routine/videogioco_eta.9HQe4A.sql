create
    definer = root@localhost procedure videogioco_eta(IN eta_min int, IN eta_max int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SELECT codice, SUM(ore_di_gioco) AS ore_totali
		FROM videogioco
		JOIN ha_nella_libreria ON videogioco.codice = ha_nella_libreria.videogioco
		JOIN giocatore ON ha_nella_libreria.username = giocatore.username
		WHERE TIMESTAMPDIFF(year, giocatore.data_nascita, current_date()) >= eta_min
		AND TIMESTAMPDIFF(year, giocatore.data_nascita, current_date()) <= eta_max
        GROUP BY codice ORDER BY SUM(ore_di_gioco) DESC LIMIT 1;
	COMMIT;
END;

