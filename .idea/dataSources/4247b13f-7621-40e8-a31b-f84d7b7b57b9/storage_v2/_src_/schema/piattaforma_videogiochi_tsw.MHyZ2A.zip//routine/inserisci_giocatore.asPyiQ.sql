create
    definer = root@localhost procedure inserisci_giocatore(IN a_username varchar(20), IN a_password varchar(25),
                                                           IN a_email varchar(35), IN a_email_recupero varchar(35),
                                                           IN a_cellulare char(10), IN a_ip varchar(20),
                                                           IN a_image mediumblob, IN a_data_nascita date,
                                                           IN a_genere enum ('m', 'f'))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO `account` VALUES (a_username, a_password, a_email, a_email_recupero, a_cellulare, current_date(), current_time(), a_ip, 1, a_image);
        INSERT INTO giocatore VALUES (a_username, a_data_nascita, current_date(), a_genere);
	COMMIT;
END;

