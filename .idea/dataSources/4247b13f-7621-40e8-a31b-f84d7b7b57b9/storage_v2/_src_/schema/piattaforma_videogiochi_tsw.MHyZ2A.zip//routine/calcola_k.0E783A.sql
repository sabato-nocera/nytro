create
    definer = root@localhost function calcola_k(a_ISIN char(12)) returns float
BEGIN
RETURN (SELECT IF(indie.ISIN IS NOT NULL,
	3 + POW(casa_editrice.numero_giochi_pubblicati + indie.numero_sviluppatori, 1/3),
    10 + POW(casa_editrice.numero_giochi_pubblicati, 1/3))
	FROM casa_editrice
    LEFT JOIN indie ON indie.ISIN = casa_editrice.ISIN
    LEFT JOIN holding ON holding.ISIN = casa_editrice.ISIN
    WHERE casa_editrice.ISIN = a_ISIN
    GROUP BY casa_editrice.ISIN);
END;

