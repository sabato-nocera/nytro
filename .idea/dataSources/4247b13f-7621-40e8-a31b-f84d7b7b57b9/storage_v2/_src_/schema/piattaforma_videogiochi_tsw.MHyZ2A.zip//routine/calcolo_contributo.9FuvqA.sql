create
    definer = root@localhost procedure calcolo_contributo(IN a_data_inizio date, IN a_data_fine date)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SELECT casa_editrice.ISIN,
		ROUND(COALESCE(SUM(Prezzo_Di_Acquisto), 0), 2) AS incassi,
		ROUND(
			COALESCE(SUM(Prezzo_Di_Acquisto), 0) * (calcola_k2(casa_editrice.ISIN, a_data_inizio, a_data_fine)/100) +
			COUNT(free_to_play.codice) * POW(calcola_k2(casa_editrice.ISIN, a_data_inizio, a_data_fine), 2)
		, 2) AS contributi_annuali,
		COUNT(free_to_play.codice) AS giochi_ftp
		FROM videogioco
		JOIN casa_editrice ON videogioco.ISIN = casa_editrice.ISIN
		LEFT JOIN holding ON holding.ISIN = casa_editrice.ISIN
		LEFT JOIN indie ON indie.ISIN = casa_editrice.ISIN
		LEFT JOIN free_to_play ON videogioco.codice = free_to_play.codice
		LEFT JOIN acquista ON (acquista.Videogioco = videogioco.codice
			AND acquista.Data >= a_data_inizio
			AND acquista.Data <= a_data_fine)
		WHERE videogioco.Data_Rilascio <= a_data_fine
		AND (videogioco.Data_Rimozione IS NULL || videogioco.Data_Rimozione >= a_data_inizio)
		GROUP BY casa_editrice.ISIN;
	COMMIT;
END;

