create
    definer = root@localhost procedure videogioco_fem()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SELECT Codice, COUNT(*) as Numero_Giocatrici, SUM(Ore_Di_Gioco) as Ore_Totali
		FROM videogioco
		JOIN ha_nella_libreria ON videogioco.codice = ha_nella_libreria.videogioco
		JOIN giocatore ON ha_nella_libreria.username = giocatore.username
		WHERE giocatore.genere = 'f'
        GROUP BY codice ORDER BY SUM(ore_di_gioco) DESC LIMIT 1;
	COMMIT;
END;

