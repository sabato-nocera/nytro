create
    definer = root@localhost procedure inserisci_azienda(IN a_username varchar(20), IN a_password varchar(25),
                                                         IN a_email varchar(35), IN a_email_recupero varchar(35),
                                                         IN a_cellulare char(10), IN a_ip varchar(20),
                                                         IN a_image mediumblob, IN a_ISIN char(12),
                                                         IN a_nome_casa varchar(30), IN a_CEO varchar(30),
                                                         IN a_sito varchar(30))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO casa_editrice VALUES (a_ISIN, a_CEO, a_sito);
		INSERT INTO `account` VALUES (a_username, a_password, a_email, a_email_recupero, a_cellulare, current_date(), current_time(), a_ip, 2, a_image);
        INSERT INTO azienda VALUES(a_username, a_ISIN, a_nome_casa);
	COMMIT;
END;

