create
    definer = root@localhost procedure assegna_ticket(IN a_codice int, IN a_ticket int, IN a_username varchar(20))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
    END;
    SET @stato = (SELECT Stato FROM ticket WHERE Numero_Progressivo = a_ticket AND Username = a_username);
    CASE WHEN (@stato != 'in attesa') 
		THEN 
			SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
        ELSE
			SET @tipo = (SELECT Impiegato FROM ticket JOIN specializzazione ON ticket.tipologia = specializzazione.ambito 
						WHERE ticket.Numero_Progressivo = a_ticket AND ticket.Username = a_username AND specializzazione.impiegato = a_codice);
			CASE WHEN (@tipo IS NULL)
				THEN
					SIGNAL SQLSTATE '45000'
					SET MESSAGE_TEXT = 'An error occurred';
				ELSE	
					START TRANSACTION;
						INSERT INTO lavora VALUES (a_codice, a_ticket, a_username);
                        UPDATE ticket SET Stato = 'in lavorazione';
					COMMIT;
		END CASE;
	END CASE;
END;

