create
    definer = root@localhost procedure inserisci_holding(IN a_username varchar(20), IN a_password varchar(25),
                                                         IN a_email varchar(35), IN a_email_recupero varchar(35),
                                                         IN a_cellulare char(10), IN a_ip varchar(20),
                                                         IN a_ISIN char(12), IN a_nome_casa varchar(30),
                                                         IN a_CEO varchar(30), IN a_sito varchar(30),
                                                         IN a_fondazione date, IN a_sede varchar(30))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		CALL inserisci_azienda(a_username, a_password, a_email, a_email_recupero, a_cellulare, a_ip, a_ISIN, a_nome_casa, a_CEO, a_sito);
        INSERT INTO holding VALUES (a_ISIN, a_fondazione, a_sede);
	COMMIT;
END;

