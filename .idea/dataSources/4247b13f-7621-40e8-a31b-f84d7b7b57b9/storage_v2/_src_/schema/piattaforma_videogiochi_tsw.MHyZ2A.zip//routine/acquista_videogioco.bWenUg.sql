create
    definer = root@localhost procedure acquista_videogioco(IN a_username char(20), IN a_codice int,
                                                           IN a_carta varchar(16), IN a_prezzo float,
                                                           IN a_IP varchar(20))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
    END;
    SET @data_rim = (SELECT Data_Rimozione FROM videogioco WHERE codice = a_codice);
    CASE WHEN (@data_rim IS NOT NULL AND @data_rim <= current_date())
		THEN 
			SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
		ELSE
			SET @pegi = (SELECT PEGI FROM videogioco WHERE codice = a_codice);
			SET @nascita = (SELECT Data_Nascita FROM giocatore WHERE Username = a_username);
			CASE WHEN ((@pegi >= 18 AND TIMESTAMPDIFF(year, @nascita, current_date()) < 18) OR (@pegi >= 18 AND @nascita IS NULL))
				THEN
					SIGNAL SQLSTATE '45000'
					SET MESSAGE_TEXT = 'An error occurred';
                ELSE
					START TRANSACTION;
						INSERT INTO acquista VALUES (a_username, a_codice, a_carta, a_prezzo, current_time(), current_date(), a_IP);
						SET @numero = (SELECT Copie_vendute FROM a_pagamento WHERE Codice = a_codice);
						UPDATE a_pagamento SET Copie_vendute = @numero+1
						WHERE codice = a_codice;
						INSERT INTO ha_nella_libreria VALUES (a_username, a_codice, default);
					COMMIT;
			END CASE;
	END CASE;
END;

