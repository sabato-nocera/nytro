create
    definer = root@localhost procedure inserisci_libreria(IN a_username char(20), IN a_codice int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
    END;
    SET @data_rim = (SELECT Data_Rimozione FROM videogioco WHERE codice = a_codice);
    CASE WHEN (@data_rim IS NOT NULL AND @data_rim <= current_date())
		THEN 
			SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'An error occurred';
		ELSE
			SET @pegi = (SELECT PEGI FROM videogioco WHERE codice = a_codice);
			SET @nascita = (SELECT Data_Nascita FROM giocatore WHERE Username = a_username);
			CASE WHEN ((@pegi >= 18 AND date_sub(@nascita, INTERVAL year(current_date()) YEAR) < 18) OR (@pegi >= 18 AND @nascita IS NULL))
				THEN
					SIGNAL SQLSTATE '45000'
					SET MESSAGE_TEXT = 'An error occurred';
                ELSE
					START TRANSACTION;
						INSERT INTO ha_nella_libreria VALUES (a_username, a_codice, default);
					COMMIT;
			END CASE;
	END CASE;
END;

