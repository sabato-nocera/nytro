create
    definer = root@localhost procedure aggiorna_recensione(IN a_codice int, IN a_username varchar(20), IN a_voto float)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SET @numero = (SELECT COUNT(*) FROM recensione WHERE recensione.videogioco = a_codice);
        SET @voto = (SELECT Voto FROM recensione WHERE recensione.videogioco = a_codice AND recensione.username = a_username);
		UPDATE recensione SET Voto = a_voto WHERE recensione.videogioco = a_codice AND recensione.username = a_username;
        UPDATE videogioco SET voto_medio = (voto_medio*@numero - @voto + a_voto)/(@numero) WHERE videogioco.codice = a_codice;
	COMMIT;
END;

