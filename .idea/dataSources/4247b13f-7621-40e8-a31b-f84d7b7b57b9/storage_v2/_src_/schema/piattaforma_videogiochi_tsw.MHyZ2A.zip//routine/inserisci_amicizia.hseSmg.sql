create
    definer = root@localhost procedure inserisci_amicizia(IN a_possessore varchar(20), IN a_amico varchar(20))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO e_nella_friendlist VALUES (a_possessore, a_amico);
        INSERT INTO e_nella_friendlist VALUES (a_amico, a_possessore);
	COMMIT;
END;

