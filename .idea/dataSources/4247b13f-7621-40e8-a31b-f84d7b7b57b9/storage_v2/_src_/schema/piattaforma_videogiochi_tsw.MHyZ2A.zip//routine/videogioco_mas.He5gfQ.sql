create
    definer = root@localhost procedure videogioco_mas()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SELECT Codice, COUNT(*) as Numero_Giocatori, SUM(Ore_Di_Gioco) as Ore_Totali
		FROM videogioco
		JOIN ha_nella_libreria ON videogioco.codice = ha_nella_libreria.videogioco
		JOIN giocatore ON ha_nella_libreria.username = giocatore.username
		WHERE giocatore.genere = 'm'
        GROUP BY codice ORDER BY SUM(ore_di_gioco) DESC LIMIT 1;
	COMMIT;
END;

