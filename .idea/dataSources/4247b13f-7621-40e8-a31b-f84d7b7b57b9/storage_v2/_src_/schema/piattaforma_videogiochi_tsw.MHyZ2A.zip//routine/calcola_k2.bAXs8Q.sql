create
    definer = root@localhost function calcola_k2(a_ISIN char(12), a_data_inizio date, a_data_fine date) returns float
BEGIN
SET @numero = (SELECT COUNT(*) FROM videogioco WHERE ISIN = a_ISIN AND videogioco.Data_Rilascio <= a_data_fine 
	AND (videogioco.data_rimozione >= a_data_inizio OR videogioco.data_rimozione IS NULL));
RETURN (SELECT IF(indie.ISIN IS NOT NULL,
	3 + POW(@numero + indie.numero_sviluppatori, 1/3),
    10 + POW(@numero, 1/3))
	FROM casa_editrice
    LEFT JOIN indie ON indie.ISIN = casa_editrice.ISIN
    LEFT JOIN holding ON holding.ISIN = casa_editrice.ISIN
    WHERE casa_editrice.ISIN = a_ISIN
    GROUP BY casa_editrice.ISIN);
END;

