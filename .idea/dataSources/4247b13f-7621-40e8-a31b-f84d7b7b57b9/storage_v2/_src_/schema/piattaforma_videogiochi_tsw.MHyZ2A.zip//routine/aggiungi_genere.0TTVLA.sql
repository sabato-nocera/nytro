create
    definer = root@localhost procedure aggiungi_genere(IN a_genere varchar(15), IN a_codice int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO piattaforma_videogiochi.genere VALUES (a_genere, a_codice);
	COMMIT;
END;

