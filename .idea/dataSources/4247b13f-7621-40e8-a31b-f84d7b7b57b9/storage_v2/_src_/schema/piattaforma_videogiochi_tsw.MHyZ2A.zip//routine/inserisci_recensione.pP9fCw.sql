create
    definer = root@localhost procedure inserisci_recensione(IN a_codice int, IN a_username varchar(20),
                                                            IN a_commento varchar(200), IN a_voto float)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		SET @numero = (SELECT COUNT(*) FROM recensione WHERE recensione.videogioco = a_codice) +1;
		INSERT INTO recensione VALUES (@numero, a_codice, a_username, a_commento , a_voto);
        UPDATE videogioco SET voto_medio = (voto_medio*(@numero-1)+a_voto)/@numero WHERE videogioco.codice = a_codice;
	COMMIT;
END;

