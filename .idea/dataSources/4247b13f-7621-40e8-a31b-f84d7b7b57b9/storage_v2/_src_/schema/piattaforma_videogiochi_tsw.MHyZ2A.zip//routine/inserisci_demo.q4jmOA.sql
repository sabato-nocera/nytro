create
    definer = root@localhost procedure inserisci_demo(IN a_ISIN char(12), IN a_data_rilascio date,
                                                      IN a_titolo varchar(50), IN a_PEGI int, IN a_image mediumblob,
                                                      IN a_genere varchar(15), IN a_principale int, IN a_durata int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;
		INSERT INTO videogioco (ISIN, Data_Rilascio, Titolo, PEGI, Img)
		VALUES (a_ISIN, a_data_rilascio, a_titolo, a_PEGI, a_image);
        SET @numero = (SELECT Codice FROM Videogioco WHERE ISIN = a_ISIN AND data_rilascio = a_data_rilascio AND titolo = a_titolo AND PEGI = a_PEGI);
		INSERT INTO demo VALUES (@numero, a_principale, a_durata);
        INSERT INTO genere VALUES (a_genere, @numero);
	COMMIT;
END;

